import { Injectable, OnModuleInit, OnModuleDestroy, Logger } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';

@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(PrismaService.name);

  async onModuleInit() {
    await this.$connect();
    this.logger.log('Connexion a PostgreSQL etablie');
  }

  async onModuleDestroy() {
    await this.$disconnect();
    this.logger.log('Connexion a PostgreSQL fermee');
  }
}
