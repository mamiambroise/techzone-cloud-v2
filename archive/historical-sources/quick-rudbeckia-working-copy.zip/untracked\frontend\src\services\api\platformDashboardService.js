import { api } from '../apiClient.js';

const unwrap = (res) => res.data;

export function getDashboard() {
  return api.get('/api/platform/dashboard').then(unwrap);
}

export function getActivity(limit = 20) {
  return api.get('/api/platform/activity', { params: { limit } }).then(unwrap);
}
