import React, { useMemo } from 'react';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { TENANTS } from '../../store/platformSlice.js';
import { ChevronDown } from 'lucide-react';
import StatusBadge from './StatusBadge.jsx';

const STATUS_MAP = {
  ACTIVE: 'ready',
  'EN TEST': 'running',
  BROUILLON: 'warning',
  SUSPENDUE: 'warning',
  ARCHIVÉE: 'inactive',
  CONFIGURING: 'running',
  VALIDATING: 'running',
  VALIDATED: 'ready',
  DRAFT: 'warning',
  SUPERSEDED: 'inactive',
  DEPRECATED: 'warning',
};

const ENV_LABEL = {
  PRODUCTION: 'Production',
  STAGING: 'Pré-production',
  TEST: 'Test',
  DEVELOPPEMENT: 'Développement',
  ARCHIVE: 'Archive',
};

export default function ContextBar() {
  const navigate = useNavigate();
  const selectedAppId = useSelector((state) => state.applications.selectedAppId);
  const applications = useSelector((state) => state.applications.applications);
  const versions = useSelector((state) => state.applications.versions);
  const activeTenant = useSelector((state) => state.platform.activeTenant);

  const tenant = useMemo(
    () => TENANTS.find((t) => t.id === activeTenant) || null,
    [activeTenant]
  );

  const app = useMemo(
    () => applications.find((a) => a.id === selectedAppId) || applications[0] || null,
    [applications, selectedAppId]
  );

  const activeVersion = useMemo(() => {
    if (!app) return null;
    const ver = versions.find((v) => v.applicationId === app.id && v.status === 'ACTIVE');
    if (ver) return ver;
    return versions.find((v) => v.applicationId === app.id) || null;
  }, [versions, app]);

  const versionLabel = useMemo(() => {
    const v = activeVersion;
    if (!v) return app?.activeVersion || '—';
    return v.version;
  }, [activeVersion, app]);

  const envCode = useMemo(() => app?.targetEnvironment || null, [app]);
  const envLabel = envCode ? (ENV_LABEL[envCode] || envCode) : null;
  const statusState = app?.status ? (STATUS_MAP[app.status] || 'inactive') : null;

  if (!app) {
    return (
      <div className="w-full overflow-hidden text-ellipsis border-b border-slate-100 bg-white px-4 py-2.5 text-xs text-slate-500">
        Aucune application sélectionnée
      </div>
    );
  }

  return (
    <div
      className="w-full border-b border-slate-100 bg-white/95 px-4 py-2.5 text-xs text-slate-800"
      role="region"
      aria-label="Contexte application"
    >
      <div className="flex flex-wrap items-center gap-3 text-[12px]">
        <button
          type="button"
          onClick={() => navigate('/applications')}
          className="flex items-center gap-1.5 font-medium text-slate-900 hover:text-blue-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-200 rounded px-1 py-0.5"
          aria-label={`Application: ${app.name}`}
        >
          <span className="truncate max-w-[180px] sm:max-w-xs">{app.name}</span>
        </button>

        <span
          className="text-slate-300"
          aria-hidden="true"
        >
          •
        </span>

        <span className="font-mono text-slate-600" title="Version active">
          Version {versionLabel}
        </span>

        <span
          className="text-slate-300"
          aria-hidden="true"
        >
          •
        </span>

        <span
          className="inline-flex items-center gap-1.5 font-mono"
          title="Environnement cible"
        >
          <span
            className={`w-1.5 h-1.5 rounded-full ${
              envCode === 'PRODUCTION'
                ? 'bg-rose-500'
                : envCode === 'STAGING'
                ? 'bg-amber-500'
                : envCode === 'TEST'
                ? 'bg-sky-500'
                : 'bg-slate-400'
            }`}
            aria-hidden="true"
          />
          <span>{envLabel || envCode || '—'}</span>
        </span>

        <span
          className="text-slate-300"
          aria-hidden="true"
        >
          •
        </span>

        <span className="inline-flex items-center gap-1.5" title={`Statut: ${app.status}`}>
          <StatusBadge state={statusState} compact />
          <span className="font-medium">{app.status}</span>
        </span>

        <div className="ml-auto flex items-center gap-1.5">
          <span className="text-slate-300" aria-hidden="true">
            •
          </span>
          <span
            className="font-medium text-slate-700"
            title={tenant ? tenant.name : 'Tenant'}
          >
            {tenant ? tenant.code : '—'}
          </span>
          <ChevronDown className="w-3 h-3 text-slate-400" aria-hidden="true" />
        </div>
      </div>
    </div>
  );
}
