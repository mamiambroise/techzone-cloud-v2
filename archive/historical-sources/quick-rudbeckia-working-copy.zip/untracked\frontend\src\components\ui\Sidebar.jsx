import React, { useEffect, useMemo } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import {
  ChevronLeft,
  ChevronRight,
  X,
  Layers,
} from 'lucide-react';
import {
  toggleSidebarCollapsed,
  setSidebarCollapsed,
  setExpandedModuleId,
} from '../../store/platformSlice.js';
import {
  sidebarSections,
  isModuleActive,
  isItemActive,
  resolveRoute,
  findActiveModule,
} from '../../app/sidebarConfig.js';
import Tooltip from './Tooltip.jsx';
import StatusBadge from './StatusBadge.jsx';

const SECTION_COLOR_MAP = {
  accueil: 'var(--tz-accent-business)',
  construction: 'var(--tz-accent-pack)',
  execution: 'var(--tz-accent-runtime)',
  'data-integrations': 'var(--tz-accent-erp)',
  plateforme: 'var(--tz-accent-platform)',
};

export default function Sidebar({ isOpen, onClose }) {
  const dispatch = useDispatch();
  const { pathname } = useLocation();
  const collapsed = useSelector((state) => state.platform.sidebarCollapsed);
  const expandedModuleId = useSelector((state) => state.platform.expandedModuleId);
  const platformHealth = useSelector((state) => state.platform.platformHealth);
  const apiStatus = useSelector((state) => state.platform.apiStatus);

  const PLATFORM_STATE = { HEALTHY: 'ready', DEGRADED: 'warning', DOWN: 'error', UNKNOWN: 'inactive' };
  const INTEGRATION_STATE = {
    CONNECTED: 'ready',
    HEALTHY: 'ready',
    CONNECTING: 'running',
    DEGRADED: 'warning',
    DISCONNECTED: 'error',
    UNKNOWN: 'inactive',
  };

  const resolveStatus = (module) => {
    if (!module.statusSource) return null;
    if (module.statusSource === 'platform') return PLATFORM_STATE[platformHealth] || 'inactive';
    if (module.statusSource === 'integration') return INTEGRATION_STATE[apiStatus] || 'inactive';
    return null;
  };

  const activeModuleId = useMemo(
    () => findActiveModule(sidebarSections, pathname),
    [pathname]
  );

  useEffect(() => {
    if (activeModuleId && expandedModuleId !== activeModuleId) {
      dispatch(setExpandedModuleId(activeModuleId));
    }
  }, [pathname, activeModuleId, dispatch]);

  const isItemRouteActive = (item) => isItemActive(item, pathname);
  const isModuleRouteActive = (module) => isModuleActive(module, pathname);

  const toggleModule = (module) => {
    if (collapsed) {
      dispatch(setSidebarCollapsed(false));
      dispatch(setExpandedModuleId(module.id));
    } else {
      dispatch(setExpandedModuleId(expandedModuleId === module.id ? null : module.id));
    }
    onClose?.();
  };

  const handleSubClick = () => {
    if (isOpen && window.innerWidth < 1024) {
      onClose?.();
    }
  };

  const renderSubItem = (item) => {
    const active = isItemRouteActive(item);
    const route = resolveRoute(item);
    const isDisabled = item.planned || !route;

    if (isDisabled) {
      return (
        <div
          key={item.id}
          className={`flex items-center gap-2.5 rounded-md px-2.5 py-2 text-sm text-slate-500 opacity-60 cursor-default`}
          aria-disabled={true}
        >
          <item.icon
            className="w-[18px] h-[18px] shrink-0 text-slate-600"
            aria-hidden="true"
          />
          {!collapsed && (
            <>
              <span className="flex-1 truncate">{item.label}</span>
              <span className="text-[10px] font-medium text-slate-600 bg-slate-800/60 px-1.5 py-0.25 rounded">
                Bientôt
              </span>
            </>
          )}
        </div>
      );
    }

    const content = (
      <NavLink
        to={route}
        end
        onClick={handleSubClick}
        className={() =>
          `flex items-center gap-2.5 rounded-md px-2.5 py-2 text-sm transition-colors
          ${
            active
              ? 'bg-slate-800/40 text-slate-100'
              : 'text-slate-300 hover:bg-slate-800/30 hover:text-slate-100'
          }`
        }
        aria-current={active ? 'page' : undefined}
      >
        <span
          className={`w-1.5 h-1.5 rounded-full shrink-0 ${
            active ? 'bg-[var(--tz-sidebar-active)]' : 'bg-transparent'
          }`}
          aria-hidden="true"
        />
        <item.icon
          className={`w-[18px] h-[18px] shrink-0 ${
            active ? 'text-[var(--tz-sidebar-active)]' : 'text-slate-400'
          }`}
          aria-hidden="true"
        />
        {!collapsed && <span className="flex-1 truncate">{item.label}</span>}
      </NavLink>
    );

    if (collapsed) {
      return (
        <Tooltip key={item.id} label={item.label}>
          <span className="block">{content}</span>
        </Tooltip>
      );
    }
    return <React.Fragment key={item.id}>{content}</React.Fragment>;
  };

  const renderModule = (module) => {
    const active = isModuleRouteActive(module);
    const isOpen2 = expandedModuleId === module.id;
    const Icon = module.icon;
    const hasChildren = module.items && module.items.length > 0;
    const moduleStatus = resolveStatus(module);

    const headerContent = (
      <>
        {moduleStatus && <StatusBadge state={moduleStatus} compact />}
        <Icon
          className={`w-[18px] h-[18px] shrink-0 ${
            active ? 'text-[var(--tz-sidebar-active)]' : 'text-slate-400'
          }`}
          aria-hidden="true"
        />
        {!collapsed && <span className="flex-1 truncate">{module.label}</span>}
        {!collapsed && hasChildren && (
          <ChevronRight
            className={`w-4 h-4 shrink-0 transition-transform text-slate-400 ${
              isOpen2 ? 'rotate-90' : ''
            }`}
            aria-hidden="true"
          />
        )}
      </>
    );

    const sharedButtonClass = `flex items-center gap-2.5 rounded-md px-2.5 py-2 text-sm font-medium transition-colors
      ${
        active
          ? 'bg-[#0e2b5a] text-white'
          : 'text-slate-300 hover:bg-slate-800/30 hover:text-slate-100'
      }`;

    return (
      <div key={module.id} className="mb-1">
        {collapsed ? (
          <Tooltip label={module.label}>
            <button
              type="button"
              onClick={() => toggleModule(module)}
              className={sharedButtonClass}
              aria-label={module.label}
              aria-expanded={isOpen2}
            >
              {headerContent}
            </button>
          </Tooltip>
        ) : (
          <button
            type="button"
            onClick={() => toggleModule(module)}
            className={sharedButtonClass}
            aria-label={module.label}
            aria-expanded={isOpen2}
            aria-controls={hasChildren ? `module-${module.id}-sub` : undefined}
          >
            {headerContent}
          </button>
        )}

        {!collapsed && hasChildren && isOpen2 && (
          <div
            id={`module-${module.id}-sub`}
            className="mt-1 ml-4 border-l border-slate-800 pl-1 space-y-0.5"
          >
            {module.items.map((item) => renderSubItem(item))}
          </div>
        )}
      </div>
    );
  };

  return (
    <>
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-950/70 lg:hidden"
          onClick={onClose}
          aria-hidden="true"
        />
      )}
      <aside
        id="main-sidebar"
        aria-label="Navigation principale"
        className={`fixed inset-y-0 left-0 z-50 flex flex-col
          bg-[#081026] text-slate-200 border-r border-slate-800
          tz-collapse-transition
          ${
            collapsed
              ? 'w-[var(--tz-sidebar-collapsed-width)]'
              : 'w-[var(--tz-sidebar-width)]'
          }
          ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        `}
        data-collapsed={collapsed ? 'true' : 'false'}
      >
        <div className="p-3 flex items-center gap-2 border-b border-slate-800">
          <Layers className="w-6 h-6 shrink-0 text-sky-400" aria-hidden="true" />
          {!collapsed && <span className="font-bold text-sm flex-1">Techzone Cloud</span>}
          <button
            type="button"
            id="sidebar-collapse-toggle"
            onClick={() => dispatch(toggleSidebarCollapsed())}
            className="hidden lg:block p-1 rounded-md text-slate-400 hover:text-slate-200 hover:bg-slate-800/40 transition-colors"
            aria-label={collapsed ? 'Agrandir le menu' : 'Réduire le menu'}
            aria-controls="main-sidebar"
            aria-expanded={!collapsed}
          >
            {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>
          <button
            type="button"
            onClick={onClose}
            className="lg:hidden p-1 rounded-md text-slate-400 hover:text-slate-200 hover:bg-slate-800/40 transition-colors"
            aria-label="Fermer le menu"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto overflow-x-hidden py-2" aria-label="Sections">
          {sidebarSections.map((section) => {
            const sectionActive = section.modules.some((m) => isModuleActive(m, pathname));
            const sectionColor = SECTION_COLOR_MAP[section.id] || 'var(--tz-accent-platform)';
            return (
              <div key={section.id} className="mb-5">
                {!collapsed && (
                  <div className="px-3 py-1.5 flex items-center gap-2">
                    <span
                      className="w-1.5 h-4 rounded-sm shrink-0"
                      style={{ backgroundColor: sectionColor }}
                      aria-hidden="true"
                    />
                    <h2
                      className="text-[10px] font-semibold uppercase tracking-wider text-slate-400"
                      title={section.label}
                    >
                      {section.label}
                    </h2>
                    {sectionActive && (
                      <span className="ml-auto text-[10px] font-medium text-[var(--tz-sidebar-active)]">
                        • actif
                      </span>
                    )}
                  </div>
                )}
                <div className="px-1 space-y-0.5">
                  {section.modules.map((module) => renderModule(module, section))}
                </div>
              </div>
            );
          })}
        </nav>

        <div className="p-3 border-t border-slate-800 flex items-center justify-between">
          {!collapsed && (
            <button
              type="button"
              onClick={() => dispatch(toggleSidebarCollapsed())}
              className="flex items-center gap-2 text-xs text-slate-400 hover:text-slate-200 hover:bg-slate-800/30 rounded-md px-2.5 py-2 transition-colors"
              aria-label="Réduire le menu"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Réduire le menu</span>
            </button>
          )}
          {collapsed && (
            <Tooltip label="Réduire le menu">
              <button
                type="button"
                onClick={() => dispatch(toggleSidebarCollapsed())}
                className="p-1.5 rounded-md text-slate-400 hover:text-slate-200 hover:bg-slate-800/30 transition-colors"
                aria-label="Réduire le menu"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
            </Tooltip>
          )}
          <span className="text-[9px] font-mono text-slate-500">v1.0</span>
        </div>
      </aside>
      <div
        aria-hidden={collapsed ? 'true' : 'false'}
        className={`hidden lg:block shrink-0 tz-collapse-transition ${
          collapsed
            ? 'w-[var(--tz-sidebar-collapsed-width)]'
            : 'w-[var(--tz-sidebar-width)]'
        }`}
      />
    </>
  );
}
