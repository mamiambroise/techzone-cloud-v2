import React from 'react';
import { screen, waitFor } from '@testing-library/react';
import { Routes, Route } from 'react-router-dom';
import { renderWithProviders, makeStore } from '../../test/testUtils.jsx';
import TechzoneLayout from '../../layouts/TechzoneLayout.jsx';

vi.mock('../../components/Header.jsx', () => ({ default: () => <header data-testid="header" /> }));
vi.mock('../../components/ApiErrorBanner.jsx', () => ({ default: () => <div data-testid="api-error-banner" /> }));
vi.mock('../../components/ToastContainer.jsx', () => ({ default: () => <div data-testid="toast-container" /> }));
vi.mock('../../components/CreateAppModal.jsx', () => ({ default: () => <div data-testid="modal" /> }));
vi.mock('../../components/CreateSnapshotModal.jsx', () => ({ default: () => <div data-testid="modal" /> }));
vi.mock('../../components/AuditLogModal.jsx', () => ({ default: () => <div data-testid="modal" /> }));

describe('TechzoneLayout (app shell)', () => {
  test('renders Sidebar, ContextBar, Header and the page outlet', async () => {
    renderWithProviders(
      <Routes>
        <Route element={<TechzoneLayout />}>
          <Route index element={<div data-testid="page-outlet">BM Applications</div>} />
          <Route path="/applications" element={<div data-testid="page-outlet">BM Applications</div>} />
        </Route>
      </Routes>,
      {
        route: '/applications',
        store: makeStore({
          platform: { activeTenant: 'tenant-enterprise' },
          applications: {
            selectedAppId: 'app-0003',
            applications: [
              { id: 'app-0003', name: 'Boutique Techzone', activeVersion: '1.2.0', status: 'ACTIVE', targetEnvironment: 'PRODUCTION' },
            ],
            versions: [],
          },
        }),
      }
    );
    expect(screen.getByLabelText('Navigation principale')).toBeInTheDocument();
    expect(screen.getByLabelText('Contexte application')).toBeInTheDocument();
    expect(screen.getByTestId('header')).toBeInTheDocument();
    expect(screen.getByTestId('page-outlet')).toHaveTextContent('BM Applications');
  });

  test('does NOT render the legacy SubNavBar duplicate navigation', () => {
    renderWithProviders(
      <Routes>
        <Route element={<TechzoneLayout />}>
          <Route index element={<div data-testid="page-outlet" />} />
          <Route path="/applications" element={<div data-testid="page-outlet" />} />
        </Route>
      </Routes>,
      {
        route: '/applications',
        store: makeStore({
          applications: {
            selectedAppId: 'app-0003',
            applications: [
              { id: 'app-0003', name: 'Boutique', activeVersion: '1.0.0', status: 'ACTIVE', targetEnvironment: 'PRODUCTION' },
            ],
            versions: [],
          },
        }),
      }
    );
    expect(screen.queryByText('Paramètres généraux')).not.toBeInTheDocument();
    const sidebar = screen.getByLabelText('Navigation principale');
    const navs = screen.getAllByRole('navigation');
    expect(navs.length).toBeGreaterThan(0);
    expect(navs.every((n) => sidebar.contains(n))).toBe(true);
  });
});
