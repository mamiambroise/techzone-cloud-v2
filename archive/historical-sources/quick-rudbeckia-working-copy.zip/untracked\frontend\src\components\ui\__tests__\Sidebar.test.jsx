import React from 'react';
import { screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { renderWithProviders, makeStore } from '../../../test/testUtils.jsx';
import Sidebar from '../Sidebar.jsx';
import { sidebarSections, findActiveModule } from '../../../app/sidebarConfig.js';

describe('Sidebar', () => {
  test('renders section structure and module labels when expanded', async () => {
    renderWithProviders(<Sidebar />, { route: '/overview' });
    expect(screen.getByText('ACCUEIL')).toBeInTheDocument();
    expect(screen.getByText('CONSTRUCTION')).toBeInTheDocument();
    expect(screen.getByText('EXÉCUTION')).toBeInTheDocument();
    expect(screen.getByText('DONNÉES & INTÉGRATIONS')).toBeInTheDocument();
    expect(screen.getByText('PLATEFORME')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Business Manager' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Automatisation' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Pack Manager' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Runtime' })).toBeInTheDocument();
  });

  test('auto-expands the accordion for the active module route', async () => {
    renderWithProviders(<Sidebar />, { route: '/overview' });
    await waitFor(() => {
      expect(screen.getByText('Vue d\'ensemble')).toBeInTheDocument();
      expect(screen.getByText('Applications')).toBeInTheDocument();
      expect(screen.getByText('Configuration')).toBeInTheDocument();
      expect(screen.getByText('Validation & publication')).toBeInTheDocument();
    });
  });

  test('clicking a module header toggles its sub-menu (accordion single-open)', async () => {
    const user = userEvent.setup();
    renderWithProviders(<Sidebar />, { route: '/' });
    const bmHeader = screen.getByRole('button', { name: 'Business Manager' });

    expect(screen.queryByText('Vue d\'ensemble')).not.toBeInTheDocument();

    await user.click(bmHeader);
    expect(screen.getByText('Vue d\'ensemble')).toBeInTheDocument();

    await user.click(bmHeader);
    expect(screen.queryByText('Vue d\'ensemble')).not.toBeInTheDocument();
  });

  test('active sub-item exposes aria-current="page"', async () => {
    renderWithProviders(<Sidebar />, { route: '/applications' });
    await waitFor(() => {
      const link = screen.getByRole('link', { name: 'Applications' });
      expect(link).toHaveAttribute('aria-current', 'page');
    });
  });

  test('parent active state differs from child active state', async () => {
    renderWithProviders(<Sidebar />, { route: '/applications' });
    const bmHeader = await screen.findByRole('button', { name: 'Business Manager' });
    expect(bmHeader).toHaveAttribute('aria-expanded', 'true');
    await waitFor(() => {
      const link = screen.getByRole('link', { name: 'Applications' });
      expect(link).toHaveAttribute('aria-current', 'page');
    });
  });

  test('collapses to icons only without text labels', () => {
    const store = makeStore({ platform: { sidebarCollapsed: true } });
    renderWithProviders(<Sidebar />, { store, route: '/' });
    const sidebar = screen.getByLabelText('Navigation principale');
    expect(sidebar).toHaveAttribute('data-collapsed', 'true');
    expect(screen.queryByText('ACCUEIL')).not.toBeInTheDocument();
    const bmButton = screen.getByRole('button', { name: 'Business Manager' });
    expect(within(bmButton).queryByText('Business Manager')).not.toBeInTheDocument();
    expect(screen.getAllByText('Business Manager').length).toBeGreaterThan(0);
  });

  test('planned items are rendered disabled', async () => {
    renderWithProviders(<Sidebar />, { route: '/overview' });
    await waitFor(() => {
      const planned = screen.getByText('Modèles de données');
      expect(planned).toBeInTheDocument();
      const disabled = planned.closest('[aria-disabled="true"]');
      expect(disabled).toBeInTheDocument();
    });
  });

  test('module header has aria-expanded and aria-controls', async () => {
    renderWithProviders(<Sidebar />, { route: '/overview' });
    const bmHeader = screen.getByRole('button', { name: 'Business Manager' });
    expect(bmHeader).toHaveAttribute('aria-expanded', 'true');
    expect(bmHeader).toHaveAttribute('aria-controls', 'module-business-manager-sub');
  });

  test('keyboard navigation reaches links via Tab', async () => {
    renderWithProviders(<Sidebar />, { route: '/applications' });
    await waitFor(() => {
      expect(screen.getByRole('link', { name: 'Applications' })).toBeInTheDocument();
    });
    const link = screen.getByRole('link', { name: 'Applications' });
    link.focus();
    expect(link).toHaveFocus();
  });

  test('findActiveModule helper resolves the correct module id', () => {
    expect(findActiveModule(sidebarSections, '/applications')).toBe('business-manager');
    expect(findActiveModule(sidebarSections, '/automation/rules')).toBe('automation');
    expect(findActiveModule(sidebarSections, '/iam/users')).toBe('platform');
    expect(findActiveModule(sidebarSections, '/erp')).toBe('erp-dolibarr');
    expect(findActiveModule(sidebarSections, '/')).toBeNull();
  });
});
