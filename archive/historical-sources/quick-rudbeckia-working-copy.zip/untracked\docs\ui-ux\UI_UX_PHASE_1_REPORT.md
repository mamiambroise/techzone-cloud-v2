# Phase 1 Report — Business Manager Studio Refondation

## Contexte

Refonte de l'expérience utilisateur du Business Manager Techzone Cloud pour le transformer en véritable studio de définition d'applications métier, connecté aux APIs réelles — sans données fictives.

**Statut :** Phase 1 — `P0.1` (Vue d'ensemble) en cours de refonte  
**Code :** PF-CDC-00 à PF-CDC-07 (série officielle)

---

## 1. Architecture Backend (NestJS 12 + Prisma 7)

### Module Platform (`/api/platform/*`)

Le backend expose un ensemble de controllers sous le préfixe `/api/platform` :

| Controller | Route | Description |
|---|---|---|
| `PlatformController` | `/api/platform/dashboard` | KPIs agrégés (applications, versions, environnements, contrats, configurations, snapshots) |
| `PlatformController` | `/api/platform/activity` | Historique d'audit agrégé (max 20 entrées) |
| `ApplicationsController` | `/api/platform/applications` | CRUD complet des applications métier |
| `ApplicationVersionsController` | `/api/platform/versions` | Gestion complète du cycle de vie des versions |
| `ApplicationVersionsController` | `/api/platform/applications/:id/versions` | Versions par application |
| `EnvironmentsController` | `/api/platform/environments` | CRUD + historique des environnements |
| `ContractsController` | `/api/platform/contracts` | Registre des contrats Platform |
| `ConfigurationController` | `/api/platform/config` | Configuration par scope (PLATFORM, APPLICATION, etc.) |
| `SnapshotController` | `/api/platform/snapshots` | Snapshots hashables et validés |

### Service `PlatformService` (dashboard + activity)

`getDashboard()` agrège en parallèle depuis Prisma :
- `applications` — total, active, archived
- `versions` — total, active, ready, draft
- `environments` — total, active, maintenance, degraded, disabled
- `contracts` — total, active, locked, deprecated, retired
- `configurations` — total, active, draft, ready
- `snapshots` — total, active, valid, invalid
- `alerts` — warnings sur snapshots invalides, environnements dégradés
- `status` — HEALTHY / WARNING / DEGRADED / CRITICAL (calculé)

`getActivity(limit = 20)` agrège l'historique depuis 4 tables Prisma (configurationHistory, environmentHistory, contractHistory, snapshotHistory) et retourne une liste uniformisée de 20 entrées d'audit maximum.

### Modèle Prisma (schéma réel)

```prisma
model Application {
  id          String            @id @default(uuid()) @db.Uuid
  code        String            @unique @db.VarChar(100)
  name        String            @db.VarChar(255)
  description String?
  status      ApplicationStatus @default(ACTIVE)
  tenantScope String            @db.VarChar(100)
  versions    ApplicationVersion[]
  createdAt   DateTime   @default(now())
  updatedAt   DateTime   @updatedAt
}

model ApplicationVersion {
  id            String                   @id @default(uuid()) @db.Uuid
  applicationId String                   @db.Uuid
  version       String                   @db.VarChar(50)
  status        ApplicationVersionStatus @default(DRAFT)
  releaseNotes  String?
  createdFrom   String?                  @db.Uuid
  publishedAt   DateTime?
  createdAt     DateTime   @default(now())
}

enum ApplicationStatus {
  ACTIVE
  ARCHIVED
}

enum ApplicationVersionStatus {
  DRAFT
  CONFIGURING
  VALIDATING
  READY
  ACTIVE
  SUPERSEDED
  DEPRECATED
  ARCHIVED
}
```

> **Note :** Le schéma Prisma ne contient pas de colonnes `category`, `owner`, `iconType`, `targetEnvironment` ou `tags` sur le modèle Application. Ces champs sont uniquement présents dans le mock Redux. La refonte Phase 1 doit gérer ces champs comme des métadonnées enrichies côté frontend ou les demander comme évolution du schéma si nécessaire.

---

## 2. Architecture Frontend

### Store Redux — Mode MOCK/REAL

Chaque slice Redux possède un système `providerMode` ('MOCK' | 'REAL') contrôlé par `integrationSlice.js` :

```
integrationSlice.state.providerMode = 'REAL'
applicationsSlice.state.applications = [initialApplications (mock)]
applicationsSlice.state.versions = [initialVersions (mock)]
```

Lorsque `providerMode === 'REAL'`, les thunks async (`fetchApplicationsAsync`, `fetchConfigsAsync`, `fetchEnvironmentsAsync`, etc.) appellent les APIs backend réelles. Lorsque `providerMode === 'MOCK'`, les requêtes sont ignorées et les données mockées restent en place.

**Slices existantes :**
- `applicationsSlice.js` — applications + versions (6 entrées mock)
- `configSlice.js` — configurations (8 entrées mock)
- `environmentsSlice.js` — environnements (4 entrées mock)
- `snapshotsSlice.js` — snapshots (3 entrées mock)
- `integrationSlice.js` — connecteurs, APIs, webhooks, credentials, sync jobs (mock + REAL)
- `platformSlice.js` — état global, IAM roles, tenants, alerts, toasts
- `auditSlice.js` — logs d'audit mock

### Composants Phase 1

| Composant | Route | Données | Statut |
|---|---|---|---|
| `GeneralOverviewView.jsx` | `/overview` | Données mock statiques | À refondre — P0.1 |
| `ApplicationsCatalogView.jsx` | `/applications` | Données mock `applicationsSlice` | À refondre |
| `WorkspaceConfigView.jsx` | `/workspace` | Données mock `configSlice` | À refondre — P1.1 |
| `VersionsDetailView.jsx` | `/versions` | Données mock `versions` | À refondre |
| `PackValidationCockpitView.jsx` | `/validation` | Données mock | À refondre — P1.2 |
| `ConfigurationView.jsx` | `/config` | Données mock partiel | À refondre |
| `SnaphotsView.jsx` | `/snapshots` | Données mock `snapshotsSlice` | À refondre |

### Navigation & Sidebar

- **`navigationConfig.js`** — 80+ définitions de routes (groups: home, business, packs, erp, automation, iam, billing, observability, platform)
- **`sidebarConfig.js`** — Structure hiérquique des sections/modules/sous-items avec support `planned: true`
- **`sidebarSections`** — Business Manager module avec items planifiés : Data Model, Features, Navigation (`planned: true`)

**Routes BM existantes :**
- `/overview` → `GeneralOverviewView` — Vue d'ensemble
- `/applications` → `ApplicationsCatalogView` — Catalogue applications
- `/workspace` → `WorkspaceConfigView` — Configuration workspace
- `/versions` → `VersionsDetailView` — Détails versions
- `/validation` → `PackValidationCockpitView` — Validation & publication
- `/config` → `ConfigurationView` — Configuration globale

### Layout commun

- **`TechzoneLayout.jsx`** — Layout principal avec Header, Sidebar, ContextBar, Footer
- **`ContextBar.jsx`** — Barre de contexte application (app sélectionnée, version, env, statut, tenant)
- **`Sidebar.jsx`** — Navigation latérale hiérarchique

---

## 3. Gap Analysis — Données fictives vs APIs réelles

### Problème principal

Tous les composants Phase 1 affichent des données **mockées statiques** initialisées au chargement de la slice Redux. Même en mode `providerMode = 'REAL'`, le `GeneralOverviewView` :
- Calcule les KPI à partir de données mockées codées en dur (ex: `03` applications actives)
- Affiche un "Cycle de vie" avec des compteurs codés en dur
- Affiche des applications récentes codées en dur
- Affiche un "Journal d'audit" avec 4 entrées mockées

### APIs réelles disponibles

| Endpoint | Méthode | Données disponibles |
|---|---|---|
| `/api/platform/dashboard` | GET | KPIs agrégés, status plateforme, alerts |
| `/api/platform/activity` | GET | Historique d'audit (configuration, environnement, contrat, snapshot) |
| `/api/platform/applications` | GET | Liste applications (id, code, name, description, status, tenantScope, createdAt, updatedAt) |
| `/api/platform/versions` | GET | Liste versions (id, applicationId, version, status, releaseNotes, createdAt, publishedAt) |
| `/api/platform/environments` | GET | Liste environnements (id, code, name, type, status, region, baseUrl) |
| `/api/platform/config` | GET | Liste configurations (key, scope, scopeId, type, value, status) |
| `/api/platform/contracts` | GET | Registre contrats |
| `/api/platform/snapshots` | GET | Snapshots |

### Champs manquants (mock-only)

Les champs suivants sont présents dans le mock mais **absents du schéma Prisma** :
- `application.category`, `application.iconType`, `application.owner`, `application.lastModifiedBy`
- `application.targetEnvironment`
- `application.tags`
- `version.testCoverage`, `version.unitTests`, `version.validations`, `version.issues`

Ces champs doivent soit :
1. Être enrichis côté frontend via un mapping/dictionnaire statique
2. Faire l'objet d'une évolution du schéma Prisma (à réserver pour un besoin fonctionnel clairement démontré)

---

## 4. Plan de travail Phase 1

### Priorité P0.1 — Vue d'ensemble (`/overview`)
- [x] Créer le rapport Phase 1
- [ ] Créer `platformDashboardService.js` (client API pour `/api/platform/dashboard` + `/api/platform/activity`)
- [ ] Créer `platformDashboardSlice.js` (Redux slice pour dashboard + activity)
- [ ] Refondre `GeneralOverviewView.jsx` pour consommer les APIs réelles

### Priorité P0.2 — Applications (`/applications`)
- [ ] Connecter `ApplicationsCatalogView.jsx` à l'API `/api/platform/applications`
- [ ] Enrichir les données mock avec des valeurs par défaut cohérentes

### Priorité P0.3 — Data Model (planifié)
- Items `planned: true` dans sidebar → à définir en Phase 2

### Priorité P0.4 — Features / Capabilities (planifié)
- Items `planned: true` dans sidebar → à définir en Phase 2

### Priorité P0.5 — Navigation (planifié)
- Items `planned:true` dans sidebar → à définir en Phase 2

### Priorité P1.1 — Configuration workspace (`/workspace`)
- Connecter `WorkspaceConfigView.jsx` à l'API `/api/platform/config`

### Priorité P1.2 — Validation / Publication (`/validation`)
- Connecter `PackValidationCockpitView.jsx` aux APIs dashboard + activity

---

## 5. Risques & Blocages

| Risque | Niveau | Mitigation |
|---|---|---|
| PostgreSQL intermittent | Moyen | Classification `DATABASE_UNAVAILABLE` dans le frontend |
| Schéma Prisma incomplet pour métadonnées UI (category, owner, icon) | Moyen | Enrichissement frontend + dictionnaire statique |
| Diagramme ER non disponible dans une lib JS | Moyen | Utiliser mermaid.js (déféré à Phase 2) |
| Données mock et données réelles divergantes | Élevé | Harmoniser : le mock devient fallback uniquement |

---

## 6. Observations techniques

- Le projet utilise **React 19 + Vite 6.2** côté frontend
- **Tailwind CSS** pour le styling (config dans `tailwind.config.js`)
- **lucide-react** pour les icônes (bibliothèque unique)
- **Axios** pour les appels HTTP (via `apiClient.js`)
- **React Router v6** pour la navigation
- **Redux Toolkit** pour la gestion d'état
- **class-variance-authority** et **clsx** pour les utils de classes
- Tokens CSS personnalisés dans `index.css` (`--tz-accent-*`)
