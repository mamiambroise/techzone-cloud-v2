import React from 'react';
import {
  CheckCircle2,
  AlertCircle,
  AlertTriangle,
  Clock,
  Layers,
} from 'lucide-react';

const STATE_CONFIG = {
  ready: { label: 'Prêt', icon: CheckCircle2, color: 'text-emerald-500', dot: 'bg-emerald-500' },
  running: { label: 'En cours', icon: Clock, color: 'text-sky-400', dot: 'bg-sky-400' },
  warning: { label: 'Attention', icon: AlertTriangle, color: 'text-amber-400', dot: 'bg-amber-400' },
  error: { label: 'Erreur', icon: AlertCircle, color: 'text-rose-400', dot: 'bg-rose-400' },
  inactive: { label: 'Non disponible', icon: Layers, color: 'text-slate-500', dot: 'bg-slate-500' },
};

export default function StatusBadge({ state, label, compact, icon: Icon, color }) {
  if (!state && !label) return null;

  if (state && STATE_CONFIG[state]) {
    const cfg = STATE_CONFIG[state];
    const IconComp = cfg.icon;
    return (
      <span
        aria-label={cfg.label}
        title={cfg.label}
        className={`inline-flex items-center justify-center rounded-full shrink-0 ${compact ? 'w-4 h-4' : 'w-5 h-5'} ${cfg.color}`}
      >
        <span className={`rounded-full ${cfg.dot} ${compact ? 'w-2 h-2' : 'w-2.5 h-2.5'}`} />
        {!compact && <span className="sr-only">{cfg.label}</span>}
      </span>
    );
  }

  if (Icon && label) {
    return (
      <span
        aria-label={label}
        title={label}
        className={`inline-flex items-center gap-1 rounded-full px-1.5 py-0.5 text-[10px] font-medium ${color || 'text-slate-400'}`}
      >
        <Icon className="w-3 h-3" />
        <span>{label}</span>
      </span>
    );
  }

  return null;
}
