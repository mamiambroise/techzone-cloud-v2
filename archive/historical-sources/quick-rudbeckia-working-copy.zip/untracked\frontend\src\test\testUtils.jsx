import React from 'react';
import { render } from '@testing-library/react';
import { Provider } from 'react-redux';
import { MemoryRouter } from 'react-router-dom';
import { configureStore } from '@reduxjs/toolkit';
import platformReducer, {
  IAM_ROLES,
  setSidebarCollapsed,
  setExpandedModuleId,
} from '../store/platformSlice.js';
import applicationsReducer from '../store/applicationsSlice.js';
import environmentsReducer from '../store/environmentsSlice.js';

const defaultPlatform = {
  activeTab: 'workspace',
  activeUser: IAM_ROLES.ADMIN,
  activeTenant: 'tenant-enterprise',
  searchQuery: '',
  platformHealth: 'HEALTHY',
  apiStatus: 'CONNECTING',
  platformContractLocked: true,
  activeModuleId: '01',
  sidebarCollapsed: false,
  expandedModuleId: null,
  providerMode: 'REAL',
  toasts: [],
  alerts: [],
};

export function makeStore(preloadedState = {}) {
  return configureStore({
    reducer: {
      platform: platformReducer,
      applications: applicationsReducer,
      environments: environmentsReducer,
      config: (s = {}) => s,
      contracts: (s = {}) => s,
      snapshots: (s = {}) => s,
      audit: (s = {}) => s,
      integration: (s = { providerMode: 'MOCK', activeIntegrationTab: 'cockpit', activeTab: 'integrations' }) => s,
      deployment: (s = { activeTab: 'cockpit' }) => s,
    },
    preloadedState: {
      platform: { ...defaultPlatform, ...preloadedState.platform },
      applications: {
        selectedAppId: 'app-0003',
        applications: [],
        versions: [],
        ...preloadedState.applications,
      },
      environments: { environments: [], ...preloadedState.environments },
      integration: { providerMode: 'MOCK', activeIntegrationTab: 'cockpit', activeTab: 'integrations', ...preloadedState.integration },
      deployment: { activeTab: 'cockpit', ...preloadedState.deployment },
      ...preloadedState,
    },
  });
}

export function renderWithProviders(ui, { store, route = '/', ...renderOptions } = {}) {
  const usedStore = store || makeStore();
  const Wrapper = ({ children }) => (
    <Provider store={usedStore}>
      <MemoryRouter initialEntries={[route]}>{children}</MemoryRouter>
    </Provider>
  );
  return { ...render(ui, { wrapper: Wrapper, ...renderOptions }), usedStore };
}

export { setSidebarCollapsed, setExpandedModuleId, defaultPlatform };
