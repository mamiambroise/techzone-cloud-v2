import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import { getDashboard, getActivity } from '../services/api/platformDashboardService.js';

export const fetchDashboardAsync = createAsyncThunk(
  'platformDashboard/fetchDashboard',
  async (_, { getState, rejectWithValue }) => {
    const { providerMode } = getState().integration;
    if (providerMode === 'MOCK') {
      return { skipped: true };
    }
    try {
      return await getDashboard();
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

export const fetchActivityAsync = createAsyncThunk(
  'platformDashboard/fetchActivity',
  async (_, { getState, rejectWithValue }) => {
    const { providerMode } = getState().integration;
    if (providerMode === 'MOCK') {
      return { skipped: true };
    }
    try {
      return await getActivity(20);
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

const platformDashboardSlice = createSlice({
  name: 'platformDashboard',
  initialState: {
    dashboard: null,
    activity: [],
    status: 'idle',
    error: null,
  },
  reducers: {
    clearError: (state) => {
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchDashboardAsync.pending, (state) => {
        state.status = 'loading';
        state.error = null;
      })
      .addCase(fetchDashboardAsync.fulfilled, (state, action) => {
        if (!action.payload.skipped) {
          state.dashboard = action.payload;
        }
        state.status = 'idle';
      })
      .addCase(fetchDashboardAsync.rejected, (state, action) => {
        state.status = 'error';
        state.error = action.payload || action.error.message;
      })
      .addCase(fetchActivityAsync.fulfilled, (state, action) => {
        if (!action.payload.skipped) {
          state.activity = action.payload;
        }
      })
      .addCase(fetchActivityAsync.rejected, (state, action) => {
        state.error = action.payload || action.error.message;
      });
  },
});

export const { clearError } = platformDashboardSlice.actions;
export default platformDashboardSlice.reducer;
