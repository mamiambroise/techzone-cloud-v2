import React from 'react';

const placementOffset = {
  right: 'left-[calc(100%+0.375rem)]',
  left: 'right-[calc(100%+0.375rem)]',
  top: 'bottom-[calc(100%+0.375rem)]',
  bottom: 'top-[calc(100%+0.375rem)]',
};

export default function Tooltip({ children, label, placement = 'right', disabled }) {
  if (!label || disabled) {
    return <>{children}</>;
  }

  return (
    <span
      className="relative inline-block cursor-pointer group"
      aria-describedby={label ? 'tz-tooltip' : undefined}
    >
      {children}
      <span
        id="tz-tooltip"
        role="tooltip"
        aria-hidden={!label}
        className={`pointer-events-none absolute z-50 whitespace-nowrap rounded-md
          bg-slate-900/95 px-2 py-1 text-[10px] font-medium text-slate-100 shadow-lg
          opacity-0 group-hover:opacity-100 focus-within:opacity-100
          transition-opacity duration-150
          ${placementOffset[placement] || placementOffset.right}
          hidden sm:inline-block`}
      >
        {label}
        <span
          aria-hidden="true"
          className="absolute top-1/2 -translate-y-1/2 w-1.5 h-1.5 -ml-0.5 rotate-45 bg-slate-900/95"
        />
      </span>
    </span>
  );
}
