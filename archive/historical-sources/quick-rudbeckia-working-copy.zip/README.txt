Snapshot of uncommitted work in quick-rudbeckia.
Base: e59c073f8715c8e625877e2d9ccaaadbb34057d9
Apply tracked-changes.patch to that base, then copy untracked/ into the checkout.
Original worktree is unchanged.
