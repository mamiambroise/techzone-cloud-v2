/**
 * Techzone Cloud — Sidebar navigation model (Phase 1).
 *
 * Hiérarchise l'ensemble des sections / modules / sous-items dans la structure
 * cible du cahier des charges UI/UX Phase 1.
 *
 * ROUTES PRÉSERVÉES : chaque item routable pointe vers une route réelle déjà
 * définie dans navigationConfig.js / App.jsx. Aucune route métier n'est
 * supprimée ni cassée ; les items `planned: true` n'ont pas encore de route
 * fonctionnelle (écrans bâtis en Phase 2) et sont rendus désactivés.
 *
 * ICÔNES : bibliothèque unique lucide-react (déjà dans package.json).
 * COULEURS : tokens CSS définis dans index.css (--tz-accent-*).
 * ÉTATS : dérivés de données réelles du store (platformHealth / apiStatus)
 *         via `statusSource`. Aucun état n'est inventé.
 */
import {
  Home,
  LayoutDashboard,
  BriefcaseBusiness,
  Box,
  Database,
  Puzzle,
  Menu,
  Settings,
  ClipboardCheck,
  PanelsTopLeft,
  GitBranch,
  ListChecks,
  Package,
  Play,
  ServerCog,
  Cloud,
  Rocket,
  ShieldCheck,
  Activity,
  ChartNoAxesCombined,
  CreditCard,
  DatabaseZap,
  Plug,
  Layers,
  Clock,
  FileText,
  Palette,
  Eye,
} from 'lucide-react';

/** Modules qui exposent un indicateur d'état dérivé du store. */
export const STATUS_SOURCES = {
  platform: 'platformHealth',
  integration: 'apiStatus',
};

export const sidebarSections = [
  {
    id: 'accueil',
    label: 'ACCUEIL',
    modules: [
      {
        id: 'accueil',
        label: 'Accueil',
        icon: Home,
        route: '/cockpit',
        color: 'var(--tz-accent-business)',
        items: [
          { id: 'dashboard', label: 'Tableau de bord', icon: LayoutDashboard, route: '/cockpit' },
        ],
      },
    ],
  },
  {
    id: 'construction',
    label: 'CONSTRUCTION',
    modules: [
      {
        id: 'business-manager',
        label: 'Business Manager',
        icon: BriefcaseBusiness,
        color: 'var(--tz-accent-business)',
        route: '/overview',
        statusSource: 'platform',
        items: [
          { id: 'bm-overview', label: 'Vue d\'ensemble', icon: LayoutDashboard, route: '/overview' },
          { id: 'bm-applications', label: 'Applications', icon: Box, route: '/applications' },
          { id: 'bm-data-model', label: 'Modèles de données', icon: Database, planned: true },
          { id: 'bm-features', label: 'Fonctionnalités', icon: Puzzle, planned: true },
          { id: 'bm-navigation', label: 'Navigation', icon: Menu, planned: true },
          { id: 'bm-configuration', label: 'Configuration', icon: Settings, route: '/workspace' },
          { id: 'bm-validation', label: 'Validation & publication', icon: ClipboardCheck, route: '/validation' },
        ],
      },
      {
        id: 'ui-builder',
        label: 'UI Builder',
        icon: PanelsTopLeft,
        color: 'var(--tz-accent-ui-builder)',
        planned: true,
        items: [
          { id: 'ui-pages', label: 'Pages', icon: LayoutDashboard, planned: true },
          { id: 'ui-forms', label: 'Formulaires', icon: Puzzle, planned: true },
          { id: 'ui-dashboards', label: 'Tableaux de bord', icon: LayoutDashboard, planned: true },
          { id: 'ui-components', label: 'Composants', icon: Box, planned: true },
          { id: 'ui-themes', label: 'Thèmes', icon: Palette, planned: true },
          { id: 'ui-preview', label: 'Prévisualisation', icon: Eye, planned: true },
        ],
      },
      {
        id: 'automation',
        label: 'Automatisation',
        icon: GitBranch,
        color: 'var(--tz-accent-automation)',
        route: '/automation',
        statusSource: 'platform',
        items: [
          { id: 'automation-dashboard', label: 'Automatisations', icon: Activity, route: '/automation' },
          { id: 'automation-rules', label: 'Règles', icon: ListChecks, route: '/automation/rules' },
          { id: 'automation-workflows', label: 'Workflows', icon: GitBranch, route: '/automation/workflows' },
          { id: 'automation-triggers', label: 'Déclencheurs', icon: Activity, route: '/automation/triggers' },
          { id: 'automation-history', label: 'Historique', icon: Clock, route: '/automation/history' },
        ],
      },
      {
        id: 'pack-manager',
        label: 'Pack Manager',
        icon: Package,
        color: 'var(--tz-accent-pack)',
        planned: true,
        items: [
          { id: 'pack-overview', label: 'Vue d\'ensemble', icon: LayoutDashboard, planned: true },
          { id: 'pack-list', label: 'Packs', icon: Package, planned: true },
          { id: 'pack-versions', label: 'Versions de packs', icon: Layers, route: '/versions' },
          { id: 'pack-modules', label: 'Modules', icon: Box, planned: true },
          { id: 'pack-capabilities', label: 'Features & Capabilities', icon: Puzzle, planned: true },
          { id: 'pack-dependencies', label: 'Dépendances', icon: GitBranch, planned: true },
          { id: 'pack-rules', label: 'Règles & Conditions', icon: ListChecks, planned: true },
          { id: 'pack-specifications', label: 'Spécifications', icon: FileText, route: '/specifications' },
          { id: 'pack-publication', label: 'Publication', icon: Rocket, route: '/publication' },
          { id: 'pack-history', label: 'Historique', icon: Clock, route: '/history' },
        ],
      },
    ],
  },
  {
    id: 'execution',
    label: 'EXÉCUTION',
    modules: [
      {
        id: 'runtime',
        label: 'Runtime',
        icon: Play,
        color: 'var(--tz-accent-runtime)',
        planned: true,
        items: [
          { id: 'runtime-overview', label: 'Vue d\'ensemble', icon: LayoutDashboard, planned: true },
          { id: 'runtime-resolutions', label: 'Résolutions', icon: Activity, planned: true },
          { id: 'runtime-manifests', label: 'Manifests', icon: FileText, planned: true },
          { id: 'runtime-effective-config', label: 'Configuration effective', icon: Settings, planned: true },
          { id: 'runtime-diagnostics', label: 'Diagnostics', icon: Activity, planned: true },
        ],
      },
    ],
  },
  {
    id: 'data-integrations',
    label: 'DONNÉES & INTÉGRATIONS',
    modules: [
      {
        id: 'data',
        label: 'Données',
        icon: Database,
        color: 'var(--tz-accent-data)',
        route: '/data-runtime',
        items: [
          { id: 'data-runtime', label: 'Vue d\'ensemble', icon: Database, route: '/data-runtime' },
          { id: 'data-runtime-history', label: 'Historique', icon: Clock, route: '/data-runtime/history' },
        ],
      },
      {
        id: 'erp-dolibarr',
        label: 'ERP / Dolibarr',
        icon: DatabaseZap,
        color: 'var(--tz-accent-erp)',
        route: '/erp',
        statusSource: 'integration',
        items: [
          { id: 'erp-overview', label: 'Vue d\'ensemble', icon: LayoutDashboard, route: '/erp' },
          { id: 'erp-connections', label: 'Connexions', icon: Plug, route: '/erps' },
          { id: 'erp-capabilities', label: 'Capabilities', icon: Puzzle, planned: true },
          { id: 'erp-mapping', label: 'Mapping', icon: GitBranch, route: '/mapping' },
          { id: 'erp-adapters', label: 'Adaptateurs', icon: DatabaseZap, route: '/adapters' },
          { id: 'erp-synchronisation', label: 'Synchronisation', icon: Clock, planned: true },
          { id: 'erp-diagnostics', label: 'Diagnostics', icon: Activity, planned: true },
        ],
      },
      {
        id: 'api-connecteurs',
        label: 'API & connecteurs',
        icon: Plug,
        color: 'var(--tz-accent-api)',
        route: '/integrations/cockpit',
        statusSource: 'integration',
        items: [
          { id: 'api-cockpit', label: 'Vue d\'ensemble', icon: LayoutDashboard, route: '/integrations/cockpit' },
          { id: 'api-connectors', label: 'Connecteurs', icon: Plug, route: '/integrations/connectors' },
          { id: 'api-apis', label: 'API', icon: PanelsTopLeft, route: '/integrations/apis' },
          { id: 'api-webhooks', label: 'Webhooks', icon: GitBranch, route: '/integrations/webhooks' },
          { id: 'api-credentials', label: 'Credentials', icon: ShieldCheck, route: '/integrations/credentials' },
          { id: 'api-sync', label: 'Synchronisation', icon: Clock, route: '/integrations/sync' },
          { id: 'api-diagnostics', label: 'Diagnostics', icon: Activity, route: '/integrations/diagnostics' },
          { id: 'api-specifications', label: 'Spécifications', icon: FileText, route: '/integrations/specifications' },
        ],
      },
    ],
  },
  {
    id: 'plateforme',
    label: 'PLATEFORME',
    modules: [
      {
        id: 'platform',
        label: 'Plateforme',
        icon: ServerCog,
        color: 'var(--tz-accent-platform)',
        route: '/environments',
        statusSource: 'platform',
        items: [
          { id: 'platform-environments', label: 'Environnements', icon: Cloud, route: '/environments' },
          { id: 'platform-deployments', label: 'Déploiements', icon: Rocket, route: '/deployment/cockpit' },
          { id: 'platform-iam', label: 'Sécurité & IAM', icon: ShieldCheck, route: '/iam/users' },
          { id: 'platform-observability', label: 'Observabilité', icon: ChartNoAxesCombined, route: '/iam/observability' },
          { id: 'platform-subscriptions', label: 'Abonnements', icon: CreditCard, route: '/billing/overview' },
          { id: 'platform-administration', label: 'Administration', icon: Settings, route: '/iam/admin' },
          { id: 'platform-contracts', label: 'Contrats', icon: FileText, route: '/contracts' },
          { id: 'platform-contract-v1', label: 'Platform Contract', icon: Layers, route: '/platform-contract' },
          { id: 'platform-snapshots', label: 'Snapshots', icon: Clock, route: '/snapshots' },
          { id: 'platform-config', label: 'Configuration', icon: Settings, route: '/config' },
          { id: 'platform-settings', label: 'Paramètres', icon: Settings, route: '/settings' },
        ],
      },
    ],
  },
];

/**
 * Retourne la route cible d'un item (null si non routable / planned).
 */
export function resolveRoute(item) {
  if (!item || item.planned || !item.route) return null;
  return item.route;
}

/**
 * Détermine si un item (module ou sous-item) correspond à la route active.
 */
export function isItemActive(item, pathname) {
  if (!item || !item.route) return false;
  if (pathname === item.route) return true;
  return pathname.startsWith(item.route + '/');
}

/**
 * Retourne l'id du module contenant une route active pour un pathname donné.
 */
export function findActiveModule(sections, pathname) {
  for (const section of sections) {
    for (const module of section.modules) {
      if (module.route && isItemActive(module, pathname)) return module.id;
      if (module.items) {
        for (const item of module.items) {
          if (item.route && isItemActive(item, pathname)) return module.id;
        }
      }
    }
  }
  return null;
}

/**
 * Détermine si un module correspond à la route active.
 */
export function isModuleActive(module, pathname) {
  if (module.route && isItemActive(module, pathname)) return true;
  if (module.items) {
    return module.items.some((item) => item.route && isItemActive(item, pathname));
  }
  return false;
}

/**
 * Détermine si un sous-item est actif (route exacte ou préfixe).
 */
export function isSubItemActive(item, pathname) {
  return isItemActive(item, pathname);
}
