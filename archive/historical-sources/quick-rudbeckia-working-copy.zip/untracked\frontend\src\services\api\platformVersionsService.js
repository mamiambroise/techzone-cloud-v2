import { api } from '../apiClient.js';

const unwrap = (res) => res.data;

export function getVersions() {
  return api.get('/api/platform/versions').then(unwrap);
}

export function getVersionsByApplication(applicationId) {
  return api.get(`/api/platform/applications/${applicationId}/versions`).then(unwrap);
}

export function cloneVersion(versionId) {
  return api.post(`/api/platform/versions/${versionId}/clone`).then(unwrap);
}

export function changeVersionStatus(versionId, status) {
  return api.post(`/api/platform/versions/${versionId}/status/${status}`).then(unwrap);
}
