import React from 'react';
import { screen, waitFor } from '@testing-library/react';
import { Routes, Route, useLocation } from 'react-router-dom';
import userEvent from '@testing-library/user-event';
import { renderWithProviders, makeStore } from '../../../test/testUtils.jsx';
import ContextBar from '../ContextBar.jsx';
import { TENANTS } from '../../../store/platformSlice.js';

const mockApplications = [
  {
    id: 'app-0003',
    name: 'Boutique Techzone',
    activeVersion: '1.2.0',
    status: 'ACTIVE',
    targetEnvironment: 'PRODUCTION',
  },
  {
    id: 'app-0002',
    name: 'Le Bistro Gourmand',
    activeVersion: 'v0.9.0',
    status: 'EN TEST',
    targetEnvironment: 'STAGING',
  },
];

describe('ContextBar', () => {
  test('renders application, version, environment, status, tenant context', async () => {
    renderWithProviders(<ContextBar />, {
      route: '/applications',
      store: makeStore({
        platform: { activeTenant: 'tenant-enterprise' },
        applications: { selectedAppId: 'app-0003', applications: mockApplications, versions: [] },
      }),
    });
    await waitFor(() => {
      expect(screen.getByText('Boutique Techzone')).toBeInTheDocument();
    });
    expect(screen.getByText('Version 1.2.0')).toBeInTheDocument();
    expect(screen.getByText('Production')).toBeInTheDocument();
    expect(screen.getByText('ACTIVE')).toBeInTheDocument();
    const tenant = TENANTS.find((t) => t.id === 'tenant-enterprise');
    expect(screen.getByText(tenant.code)).toBeInTheDocument();
  });

  test('status maps to a ready indicator for ACTIVE applications', async () => {
    renderWithProviders(<ContextBar />, {
      route: '/applications',
      store: makeStore({
        platform: { activeTenant: 'tenant-enterprise' },
        applications: { selectedAppId: 'app-0003', applications: mockApplications, versions: [] },
      }),
    });
    await waitFor(() => {
      expect(screen.getByText('ACTIVE')).toBeInTheDocument();
    });
    expect(screen.getByTitle('Prêt')).toBeInTheDocument();
  });

  test('status maps to a running indicator for EN TEST applications', async () => {
    renderWithProviders(<ContextBar />, {
      route: '/applications',
      store: makeStore({
        platform: { activeTenant: 'tenant-enterprise' },
        applications: { selectedAppId: 'app-0002', applications: mockApplications, versions: [] },
      }),
    });
    await waitFor(() => {
      expect(screen.getByText('EN TEST')).toBeInTheDocument();
    });
    expect(screen.getByTitle('En cours')).toBeInTheDocument();
  });

  test('clicking the application name navigates to /applications', async () => {
    const user = userEvent.setup();
    function LocationDisplay() {
      const loc = useLocation();
      return <div data-testid="loc">{loc.pathname}</div>;
    }
    renderWithProviders(
      <Routes>
        <Route
          path="*"
          element={
            <>
              <ContextBar />
              <LocationDisplay />
            </>
          }
        />
      </Routes>,
      {
        route: '/workspace',
        store: makeStore({
          platform: { activeTenant: 'tenant-enterprise' },
          applications: { selectedAppId: 'app-0003', applications: mockApplications, versions: [] },
        }),
      }
    );
    const appButton = await screen.findByRole('button', { name: 'Application: Boutique Techzone' });
    await user.click(appButton);
    await waitFor(() => {
      expect(screen.getByTestId('loc').textContent).toBe('/applications');
    });
  });
});
